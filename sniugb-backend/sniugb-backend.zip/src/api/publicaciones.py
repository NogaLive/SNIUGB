import bleach
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import desc
from src.utils.security import get_db
from src.models import database_models as models
from src.models.admin_models import ArticulosResponse, ArticuloSchema 

publicaciones_router = APIRouter(
    prefix="/publicaciones",
    tags=["Publicaciones Públicas"],
)

@publicaciones_router.get("/populares", response_model=list[ArticuloSchema])
def get_articulos_populares(db: Session = Depends(get_db)):
    """Devuelve los 5 artículos con más vistas."""
    return db.query(models.Articulo)\
        .filter(models.Articulo.estado_publicacion == "publicado")\
        .order_by(desc(models.Articulo.vistas))\
        .limit(5)\
        .all()

@publicaciones_router.get("/recientes", response_model=list[ArticuloSchema])
def get_articulos_recientes(db: Session = Depends(get_db)):
    """Devuelve los 5 artículos más recientes."""
    return db.query(models.Articulo)\
        .filter(models.Articulo.estado_publicacion == "publicado")\
        .order_by(desc(models.Articulo.fecha_publicacion))\
        .limit(5)\
        .all()

@publicaciones_router.get("/", response_model=ArticulosResponse)
def get_publicaciones(
    db: Session = Depends(get_db),
    page: int = Query(1, ge=1),
    limit: int = Query(6, ge=1),
    categoria_id: int | None = Query(None)
):
    """
    Obtiene una lista paginada de artículos para el público, con filtro opcional por ID de categoría.
    Devuelve un objeto con la lista de artículos y metadatos de paginación.
    """
    # 1. Construimos la consulta base con carga optimizada de relaciones (JOINs)
    query = db.query(models.Articulo).options(
        joinedload(models.Articulo.categoria),
        joinedload(models.Articulo.autor)
    ).filter(models.Articulo.estado_publicacion == "publicado")

    # 2. Aplicamos el filtro si se proporciona un ID de categoría
    if categoria_id is not None:
        query = query.filter(models.Articulo.categoria_id == categoria_id)
        
    # 3. Calculamos el total de artículos (después de filtrar)
    total_articulos = query.count()
    
    # 4. Aplicamos la paginación
    offset = (page - 1) * limit
    articulos = query.order_by(models.Articulo.fecha_publicacion.desc()).offset(offset).limit(limit).all()
    
    # 5. Calculamos el total de páginas
    total_pages = (total_articulos + limit - 1) // limit

    # 6. Devolvemos la respuesta en el formato que el frontend espera
    return {
        "articulos": articulos,
        "total": total_articulos,
        "page": page,
        "pages": total_pages
    }


@publicaciones_router.get("/{articulo_slug}", response_model=ArticuloSchema)
def get_articulo_by_slug(articulo_slug: str, db: Session = Depends(get_db)):
    """Obtiene el detalle de un artículo específico por su SLUG."""
    articulo = db.query(models.Articulo).options(
        joinedload(models.Articulo.categoria),
        joinedload(models.Articulo.autor)
    ).filter(
        models.Articulo.slug == articulo_slug, 
        models.Articulo.estado_publicacion == "publicado"
    ).first()
    
    if not articulo:
        raise HTTPException(status_code=404, detail="Artículo no encontrado.")
    # Incrementar el contador de vistas
    articulo.vistas += 1
    db.commit()
    db.refresh(articulo)
    # Sanitizar HTML
    try:
        articulo.contenido_html = bleach.clean(articulo.contenido_html, tags=bleach.sanitizer.ALLOWED_TAGS.union({'p','img','h1','h2','h3','ul','ol','li','strong','em','a','blockquote','code','pre'}), attributes={'a':['href','title','target','rel'],'img':['src','alt','title']}, strip=True)
    except Exception:
        pass
    return articulo