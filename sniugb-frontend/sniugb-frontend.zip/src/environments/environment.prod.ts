export const environment = {
  production: true,
  apiBaseUrl: 'https://api.sniugb.gob.pe/api/v1'
};
