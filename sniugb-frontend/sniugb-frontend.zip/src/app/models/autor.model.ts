export interface Autor {
  numero_de_dni: string;
  nombre_completo: string;
}